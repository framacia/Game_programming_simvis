﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D playerShip;
        Vector2 playerPosition, enemyPosition, mousePosition;
        Vector2 moveRight, moveLeft, moveUp, moveDown;
       

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            playerPosition = new Vector2(0, 0);
            enemyPosition = new Vector2(475, 75);
            moveRight = new Vector2(2, 0);
            moveLeft = new Vector2(-2, 0);
            moveUp = new Vector2(0, -2);
            moveDown = new Vector2(0, 2);



            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            playerShip = Content.Load<Texture2D>("player");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            MouseState mouseState = Mouse.GetState();
            KeyboardState keyboardState = Keyboard.GetState();

            IsMouseVisible = true;
            System.Diagnostics.Debug.WriteLine("Mouse  at:  " + mouseState.X + "," + mouseState.Y);
            mousePosition = new Vector2(mouseState.X, mouseState.Y);

            if (keyboardState.IsKeyDown(Keys.Right))
                playerPosition += moveRight;
            if (keyboardState.IsKeyDown(Keys.Left))
                playerPosition += moveLeft;
            if (keyboardState.IsKeyDown(Keys.Up))
                playerPosition += moveUp;
            if (keyboardState.IsKeyDown(Keys.Down))
                playerPosition += moveDown;

            if (playerPosition.X >= 800 - playerShip.Width / 2)
                playerPosition += moveLeft;
            if (playerPosition.X <= 0 + playerShip.Width / 2)
                playerPosition += moveRight;
            if (playerPosition.Y >= 480 - playerShip.Height / 2)
                playerPosition += moveUp;
            if (playerPosition.Y <= 0 + playerShip.Height / 2)
                playerPosition += moveDown;

            if (mouseState.LeftButton == ButtonState.Pressed)
            {
                playerPosition.X = mouseState.X;
                playerPosition.Y = mouseState.Y;
            }
                
                base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.TransparentBlack);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            spriteBatch.Draw(playerShip, 
                playerPosition, 
                rotation: 0, 
                origin: new Vector2(playerShip.Width / 2, playerShip.Height / 2),
                color: Color.White);                 // Depth
            spriteBatch.Draw(playerShip, enemyPosition, Color.Red);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
